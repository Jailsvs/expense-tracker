import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { ConfigService } from '../../core/services/FIREBASE-config.service';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss'
})
export class HeaderComponent implements OnInit {
  isDarkTheme = false;
  isMenuOpen = false;

  constructor(
    private configService: ConfigService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.configService.config$.subscribe(config => {
      this.isDarkTheme = config.theme === 'dark';
    });
  }

  toggleTheme(): void {
    const newTheme = this.isDarkTheme ? 'light' : 'dark';
    this.configService.setTheme(newTheme);
  }

  toggleMenu(): void {
    this.isMenuOpen = !this.isMenuOpen;
  }

  closeMenu(): void {
    this.isMenuOpen = false;
  }
}
